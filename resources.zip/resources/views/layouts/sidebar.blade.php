<div class="sidebar-category sidebar-category-visible">
    <div class="category-content no-padding">
        <ul class="navigation navigation-main navigation-accordion">

            <!-- Main -->
            <li class="navigation-header"><span>Main</span> <i class="icon-menu" title="Main pages"></i></li>
            <li><a href="{{url('admin/dashboard')}}"><i class="icon-home4"></i> <span>Dashboard</span></a></li>
            <li class="navigation-header"><span>Master Data</span> <i class="icon-menu" title="Main pages"></i></li>
            <li><a href="{{route('user.index')}}"><i class="icon-user"></i> <span>User</span></a></li>
            <li><a href="{{route('quizcategory.index')}}"><i class="icon-home4"></i> <span>Category</span></a></li>
            <li><a href="{{route('quiztype.index')}}"><i class="icon-home4"></i> <span>Type</span></a></li>
            <li><a href="{{route('quiz.index')}}"><i class="icon-home4"></i> <span>Quiz</span></a></li>
            <li><a href="{{route('banner.index')}}"><i class="icon-home4"></i> <span>Banner</span></a></li>
            <!-- /main -->

        </ul>
    </div>
</div>
